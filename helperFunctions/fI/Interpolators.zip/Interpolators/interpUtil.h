#ifndef _INTERP_UTIL_H_
#define _INTERP_UTIL_H_

#include "mex.h"

void ppuval( int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[] );

void ppmval( int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[] );


#endif // INTERP_UTIL_H
                  
     
                  
                  