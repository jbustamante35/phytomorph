#include "mex.h"
#include "interpUtil.h"

void mexFunction( int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[] )
{
    ppuval(nlhs, plhs, nrhs, prhs );
}
