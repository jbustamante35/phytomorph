
#include "mex.h"
#include "interpUtil.h"

// Main function ===============================================================
void mexFunction( int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[] ) {
   
    ppmval(nlhs, plhs, nrhs, prhs );
    
};




