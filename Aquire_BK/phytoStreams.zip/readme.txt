December 16, 2019 - This streams package should init a stream object over which data can be seent.
