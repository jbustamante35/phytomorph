#!/bin/bash
D=$(date +"%m-%d-%y")
zip -r /mnt/scratch1/phytomorph_dev/Aquire/phytoStreams.zip /mnt/scratch1/phytomorph_dev/Aquire/phytoStreams
imv /iplant/home/nmiller/publicData/phytoStreams/phytoStreams.zip /iplant/home/nmiller/publicData/phytoStreams/phytoStreams_$D.zip
iput -f /mnt/scratch1/phytomorph_dev/Aquire/phytoStreams.zip /iplant/home/nmiller/publicData/phytoStreams/
