The init command of usb_init_port will take a user through the process of
plugging in usb scanners 
