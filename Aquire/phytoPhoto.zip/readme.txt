The init command of addPort will take a user through the process of
plugging in usb scanners.
ToDo:19-12-20:add qr generating script after adding scanner or camera.
ToDo:19-12-10:remove the ./ from each command and make sure that the "pathing"
is working


