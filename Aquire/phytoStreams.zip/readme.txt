December 16, 2019 - This streams package should init a stream object over which data can be sent.

Streams are labled by program
Streams have a type - cyverseStream/cyverseBuffer
Streams have a number.  This allows each program to have many streams
Streams are active -> active=1 or inactivce -> active=0

